import java.util.Scanner;
class Main {
    public static void main(String[] args) {

        double x = 0.0;
        double y = 0.0;
        double z = 0.0;

        Scanner leitor = new Scanner(System.in);

        System.out.println("Digite o valor X:");
        x = leitor.nextDouble();

        System.out.println("Digite o valor Y:");
        y = leitor.nextDouble();

        System.out.println("Digite o valor Z:");
        z = leitor.nextDouble();

        double calculo = 4 / 3 * (Math.pow(((x * x) + (y * y) - (x * y)), 0.75)) + z;
        System.out.println(calculo);
        
    }
}                       