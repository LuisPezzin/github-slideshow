import java.text.BreakIterator;
import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner teclado = new Scanner(System.in);
    int tecH = 01;
    int tecM = 01;
    int tecS = 59;
    int tecMS =500;
    int escolha = 0;
    boolean ciclo = false;
    System.out.print("gostaria de manter o hora proposto? \n 1 - definir hora a gosto \n 2 - deixar como o sistema deixa como opção \n");
    escolha = teclado.nextInt();
    if (escolha == 1){
      System.out.print("\n hora que gostaria de iniciar?' \n");
      tecH = teclado.nextInt();
      
      System.out.print("\n Minuto que gostaria de iniciar' \n");
      tecM = teclado.nextInt();
      
      System.out.print("\nSegundo que gostaria de iniciar'\n ");
      tecS = teclado.nextInt();

      System.out.print("\nMilésimo que ggostaria de iniciar' \n");
      tecMS = teclado.nextInt();
    
      Hora h = new Hora();
      h.setHora(tecH);
      h.setMinuto(tecM);
      h.setSegundo(tecS);
      h.setMiliSegundo(tecMS);
      h.imprimir();
      h.min();
      h.sec();
      h.milisec();
      h.horas(); 
      System.out.print("como ficou o horario: \n");
      h.imprimir();

      while(ciclo == false){
        System.out.print(" \n gostaria de adicionar ou diminuir horas? \n 1 - Sim \n 2 - Não \n");
        escolha = teclado.nextInt();
        if(escolha == 1){
          System.out.print("para subtrair precisa do cinal menos(-)");

          System.out.print("\n hora que gostariade alterar 'adicionar ou diminuir' \n");
          tecH = teclado.nextInt();
          
          System.out.print("\n Minuto que gostariade alterar 'adicionar ou diminuir' \n");
          tecM = teclado.nextInt();
          
          System.out.print("\nSegundo que gostariade alterar 'adicionar ou diminuir'\n ");
          tecS = teclado.nextInt();

          System.out.print("\nMilésimo que gostariade alterar 'adicionar ou diminuir' \n");
          tecMS = teclado.nextInt();
          
          h.setHora(tecH);
          h.setMinuto(tecM);
          h.setSegundo(tecS);
          h.setMiliSegundo(tecMS);
          h.min();
          h.sec();
          h.milisec();
          h.horas(); 
          System.out.print("como ficou o horario: \n");
          h.imprimir();

        } else if(escolha != 1 ){
          ciclo = true;
        }
      }
    } 
    if (escolha == 2){
      Hora h = new Hora();
      h.imprimir();
      h.setHora(tecH);
      h.setMinuto(tecM);
      h.setSegundo(tecS);
      h.setMiliSegundo(tecMS);
      h.imprimir();
      h.min();
      h.sec();
      h.milisec();
      h.horas();
    }
    if (escolha > 2){
      System.out.print("\n ops, parece que fez uma escolha errada então vamos fechar esse programa"); 
    }
  }
}