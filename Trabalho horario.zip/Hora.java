public class Hora {

  public int hora;
  public int min;
  public int sec;
  public int miliSec;
  int TempoTotalH = 00;
  int TempoTotalM = 00;
  int TempoTotalS = 00;
  int TempoTotalMS = 00;
  int TempoTotal = 00;
  int resto;
  void setHora(int hora){
    this.hora = hora; 
    this.TempoTotalH += this.hora;
  }

  void setMinuto(int minuto){
    this.min = minuto;
    this.TempoTotalM += this.min;
  }

  void setSegundo(int segundo){
    this.sec = segundo;
    this.TempoTotalS += this.sec;
  }

  void setMiliSegundo(int miliSegundo){
    this.miliSec = miliSegundo;
    this.TempoTotalMS += this.miliSec;
  }


  
  void milisec(){

    if (TempoTotalMS > 999){
      TempoTotalMS = TempoTotalMS - 1000;
      TempoTotalS +=  1;
    }
  }
  void sec(){

    while (TempoTotalS >= 60){
      TempoTotalS = TempoTotalS - 60;
      TempoTotalM +=  1;
    }
  }  

  void min(){

    while (TempoTotalM >= 60){
      TempoTotalM = TempoTotalM - 60;
      TempoTotalH +=  1;
    }
  }
  void horas(){
    while(TempoTotalH >= 24){
      TempoTotalH = TempoTotalH -24;
    }
  }
  
  void imprimir (){
    if (TempoTotalH >= 12){
    System.out.println(TempoTotalH + ":" + TempoTotalM + ":" + TempoTotalS + "." + TempoTotalMS + " PM");
    } if (TempoTotalH <= 11){
    System.out.println(TempoTotalH + "." + TempoTotalM + ":" + TempoTotalS + "." + TempoTotalMS + " AM");
    }
  }

}