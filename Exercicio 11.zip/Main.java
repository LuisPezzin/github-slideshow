class Main {
  public static void main(String[] args) {
    double f = 0.0;
    double x = 0.0;
    double y = 0.0;

    System.out.print("Digite o valor de X: ");
    double x = teclado.nextInt();
    System.out.print("Digite o valor de Y: ");
    double y = teclado.nextInt();

    double a = Math.abs(Math.sin(x)*Math.sin(y));

    double b = Math.abs(Math.sqrt((Math.pow(x, 2) + Math.pow(y, 2))/Math.PI));

    double c = Math.abs(a * Math.exp(b));
    
    f =  -0.0001 * Math.pow((c+1), 0.1);
    System.out.print(f);
  }
}                    